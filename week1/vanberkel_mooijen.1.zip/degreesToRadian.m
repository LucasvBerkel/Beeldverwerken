function [ radian ] = degreesToRadian( degrees )
%% Function returns the corresponding radian value to the degrees
radian = (pi/180)*degrees;
return
end

